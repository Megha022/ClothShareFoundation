// donation.ts
export class Donation {
    id:number;
    mobileNumber: number;
    name: string;
    location: string;
    category: string;
    quantity: number;

    constructor(){
      this.id=0;
      this.mobileNumber=0;
      this.name='';
      this.location='';
      this.category='';
      this.quantity=0;
    }
    

  }
  