package com.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.model.Donar;

public interface DonarRepository extends JpaRepository<Donar, Integer> {

}
